import { createBrowserClient } from "@supabase/ssr";
import type { CourseType } from "@/types/common.types";
import type { Database } from "@/types/database.types";
import type { ParentListItem, ScheduleSessionDetails, ScheduleSessionItem, StudentListItem, TeacherListItem } from "@/types/crm";
import { readStorage, writeStorage, isBrowser } from "@/services/storage";
import { listParents } from "@/services/parents.service";
import { listStudents } from "@/services/students.service";
import { listTeachers } from "@/services/teachers.service";

const SCHEDULE_KEY = "skidy.crm.schedule";
const VALID_COURSES: CourseType[] = ["scratch", "python", "web", "ai"];

const DEFAULT_SCHEDULE: ScheduleSessionItem[] = [
  { id: "1", classId: "class-1", teacherId: "1", day: 0, startTime: "16:00", endTime: "17:00", className: "Scratch A", teacher: "أ. محمود", students: 5, course: "scratch", sessionDate: null },
  { id: "2", classId: "class-2", teacherId: "2", day: 0, startTime: "17:30", endTime: "18:30", className: "Python A", teacher: "أ. دينا", students: 4, course: "python", sessionDate: null },
  { id: "3", classId: "class-3", teacherId: "3", day: 1, startTime: "16:00", endTime: "17:00", className: "Scratch B", teacher: "أ. كريم", students: 6, course: "scratch", sessionDate: null },
  { id: "4", classId: "class-4", teacherId: "2", day: 2, startTime: "18:00", endTime: "19:00", className: "AI Intro", teacher: "أ. دينا", students: 3, course: "ai", sessionDate: null },
  { id: "5", classId: "class-5", teacherId: "3", day: 3, startTime: "17:00", endTime: "18:00", className: "Web Starters", teacher: "أ. كريم", students: 4, course: "web", sessionDate: null },
  { id: "6", classId: "class-6", teacherId: "1", day: 4, startTime: "16:30", endTime: "17:30", className: "Scratch Trial", teacher: "أ. محمود", students: 5, course: "scratch", sessionDate: null },
];

function getSupabaseClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key || !isBrowser()) return null;
  return createBrowserClient<Database>(url, key);
}

function isDemoModeEnabled(): boolean {
  return process.env.NEXT_PUBLIC_ALLOW_DEMO_FALLBACK === "true";
}

function shouldUseDemoFallback(): boolean {
  return !getSupabaseClient() && isDemoModeEnabled();
}

function sortSessions(items: ScheduleSessionItem[]): ScheduleSessionItem[] {
  return [...items].sort((a, b) => {
    if (a.day !== b.day) return a.day - b.day;
    return a.startTime.localeCompare(b.startTime);
  });
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.trim().length > 0 ? value : fallback;
}

function asNullableString(value: unknown): string | null {
  return typeof value === "string" && value.trim().length > 0 ? value : null;
}

function asNumber(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
  }
  return fallback;
}

function readRecordValue(record: unknown, keys: string[]): unknown {
  if (!record || typeof record !== "object") return undefined;
  const objectRecord = record as Record<string, unknown>;
  for (const key of keys) {
    if (key in objectRecord) return objectRecord[key];
  }
  return undefined;
}

function readDayValue(record: unknown, fallback = 0): number {
  return asNumber(readRecordValue(record, ["day_of_week", "weekday", "day"]), fallback);
}

function asCourse(value: unknown, fallback: CourseType = "scratch"): CourseType {
  return VALID_COURSES.includes(value as CourseType) ? (value as CourseType) : fallback;
}

function normalizeName(value: string | null | undefined): string {
  return (value ?? "")
    .toLowerCase()
    .replace(/أ\.?\s*/g, "")
    .replace(/[\u064B-\u065F]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function getLocalSchedule(): ScheduleSessionItem[] {
  const seed = shouldUseDemoFallback() ? DEFAULT_SCHEDULE : ([] as ScheduleSessionItem[]);
  return sortSessions(readStorage(SCHEDULE_KEY, seed));
}

function saveLocalSchedule(items: ScheduleSessionItem[]): void {
  writeStorage(SCHEDULE_KEY, sortSessions(items));
}

function clearLocalSchedule(): void {
  writeStorage(SCHEDULE_KEY, []);
}

function inferTeacher(
  teacherId: string | null,
  rawTeacher: unknown,
  teachers: TeacherListItem[],
): TeacherListItem | null {
  if (teacherId) {
    const direct = teachers.find((teacher) => teacher.id === teacherId);
    if (direct) return direct;
  }

  const byName = asString(rawTeacher);
  if (!byName) return null;
  const target = normalizeName(byName);
  return teachers.find((teacher) => {
    const name = normalizeName(teacher.fullName);
    return name.includes(target) || target.includes(name);
  }) ?? null;
}

function mapSessionFromClass(
  row: Database["public"]["Tables"]["classes"]["Row"],
  teachers: TeacherListItem[],
  enrollmentCount: number,
): ScheduleSessionItem {
  const teacher = inferTeacher(row.teacher_id, null, teachers);
  return {
    id: asString(row.id, crypto.randomUUID()),
    classId: asNullableString(row.id),
    teacherId: asNullableString(row.teacher_id),
    day: readDayValue(row, 0),
    startTime: asString(row.start_time, "16:00"),
    endTime: asString(row.end_time, "17:00"),
    className: asString(row.name, "Class"),
    teacher: teacher?.fullName ?? "مدرس غير محدد",
    students: enrollmentCount,
    course: asCourse(row.course),
    sessionDate: null,
  } satisfies ScheduleSessionItem;
}

function mapSessionFromSessionRow(
  row: Database["public"]["Tables"]["sessions"]["Row"],
  classMap: Map<string, Database["public"]["Tables"]["classes"]["Row"]>,
  teachers: TeacherListItem[],
  studentsCount: number,
): ScheduleSessionItem {
  const classRow = row.class_id ? classMap.get(row.class_id) ?? null : null;
  const teacher = inferTeacher(asNullableString(row.teacher_id ?? classRow?.teacher_id), null, teachers);
  return {
    id: asString(row.id, crypto.randomUUID()),
    classId: asNullableString(row.class_id),
    teacherId: asNullableString(row.teacher_id ?? classRow?.teacher_id),
    day: readDayValue(row, readDayValue(classRow, 0)),
    startTime: asString(row.start_time ?? classRow?.start_time, "16:00"),
    endTime: asString(row.end_time ?? classRow?.end_time, "17:00"),
    className: asString(row.title ?? classRow?.name, "Session"),
    teacher: teacher?.fullName ?? "مدرس غير محدد",
    students: studentsCount,
    course: asCourse(row.status === "trial" ? classRow?.course ?? "scratch" : classRow?.course),
    sessionDate: asNullableString(row.session_date),
  } satisfies ScheduleSessionItem;
}

async function buildStudentsTeachersParents() {
  const [students, teachers, parents] = await Promise.all([listStudents(), listTeachers(), listParents()]);
  return { students, teachers, parents };
}

export async function listScheduleSessions(): Promise<ScheduleSessionItem[]> {
  const local = getLocalSchedule();
  const demoFallback = shouldUseDemoFallback() ? (local.length > 0 ? local : DEFAULT_SCHEDULE) : [];
  const supabase = getSupabaseClient();
  if (!supabase) return demoFallback;

  try {
    const [{ students, teachers }, classesResponse, sessionsResponse, enrollmentsResponse] = await Promise.all([
      buildStudentsTeachersParents(),
      supabase.from("classes").select("*"),
      supabase.from("sessions").select("*").order("session_date", { ascending: false }),
      supabase.from("class_enrollments").select("*"),
    ]);

    const classesRows = classesResponse.data ?? [];
    const sessionRows = sessionsResponse.data ?? [];
    const enrollmentRows = enrollmentsResponse.data ?? [];

    if (classesResponse.error || sessionsResponse.error || enrollmentsResponse.error) {
      console.error("[schedule] failed to load from Supabase", classesResponse.error || sessionsResponse.error || enrollmentsResponse.error);
      clearLocalSchedule();
      return [];
    }

    if (classesRows.length === 0 && sessionRows.length === 0) {
      clearLocalSchedule();
      return [];
    }

    const enrollmentCountByClassId = new Map<string, number>();
    enrollmentRows.forEach((row) => {
      if (!row.class_id) return;
      const isActive = row.is_active ?? true;
      if (!isActive) return;
      enrollmentCountByClassId.set(row.class_id, (enrollmentCountByClassId.get(row.class_id) ?? 0) + 1);
    });

    const classMap = new Map(classesRows.map((row) => [row.id, row]));
    const classIdsWithSessions = new Set(sessionRows.map((row) => row.class_id).filter((id): id is string => Boolean(id)));

    const mappedFromSessions = sessionRows.map((row) => {
      const studentsCount = row.class_id ? (enrollmentCountByClassId.get(row.class_id) ?? 0) : 0;
      return mapSessionFromSessionRow(row, classMap, teachers, studentsCount);
    });

    const mappedStandaloneClasses = classesRows
      .filter((row) => !classIdsWithSessions.has(row.id))
      .map((row) => mapSessionFromClass(row, teachers, enrollmentCountByClassId.get(row.id) ?? students.filter((student) => student.className === row.name).length));

    const merged = sortSessions([...mappedFromSessions, ...mappedStandaloneClasses]);
    saveLocalSchedule(merged);
    return merged;
  } catch (error) {
    console.error("[schedule] unexpected load failure", error);
    clearLocalSchedule();
    return [];
  }
}

export async function getScheduleSessionById(id: string): Promise<ScheduleSessionItem | null> {
  const items = await listScheduleSessions();
  return items.find((session) => session.id === id) ?? null;
}

export async function getScheduleSessionDetails(id: string): Promise<ScheduleSessionDetails | null> {
  const [session, students, teachers, parents, allSessions] = await Promise.all([
    getScheduleSessionById(id),
    listStudents(),
    listTeachers(),
    listParents(),
    listScheduleSessions(),
  ]);

  if (!session) return null;

  const teacherRecord = session.teacherId
    ? teachers.find((teacher) => teacher.id === session.teacherId) ?? null
    : teachers.find((teacher) => normalizeName(teacher.fullName) === normalizeName(session.teacher)) ?? null;

  const linkedStudents = students.filter((student) => {
    const classMatch = student.className ? normalizeName(student.className) === normalizeName(session.className) : false;
    const courseMatch = student.currentCourse === session.course;
    return classMatch || courseMatch;
  });

  const linkedParentIds = Array.from(new Set(linkedStudents.map((student) => student.parentId).filter((value): value is string => Boolean(value))));
  const linkedParents = parents.filter((parent) => linkedParentIds.includes(parent.id));
  const siblingSessions = allSessions.filter((item) => item.id !== session.id && ((session.classId && item.classId === session.classId) || normalizeName(item.className) === normalizeName(session.className)));

  return {
    ...session,
    teacherRecord,
    linkedStudents,
    linkedParentIds,
    linkedParents,
    siblingSessions,
  };
}

export async function getScheduleOverview() {
  const sessions = await listScheduleSessions();
  const totalStudents = sessions.reduce((sum, session) => sum + session.students, 0);
  const uniqueTeachers = new Set(sessions.map((session) => session.teacherId ?? session.teacher)).size;
  const busiestDay = sessions.reduce(
    (acc, session) => {
      acc[session.day] = (acc[session.day] ?? 0) + 1;
      return acc;
    },
    {} as Record<number, number>,
  );

  const busiestDayEntry = Object.entries(busiestDay).sort((a, b) => Number(b[1]) - Number(a[1]))[0];

  return {
    sessionsCount: sessions.length,
    totalStudents,
    uniqueTeachers,
    busiestDay: busiestDayEntry ? Number(busiestDayEntry[0]) : 0,
    busiestDayCount: busiestDayEntry ? Number(busiestDayEntry[1]) : 0,
  };
}
