/**
 * Lead stages configuration
 * Maps to the sales system we designed earlier
 * @author Abdelrahman
 */

export interface StageConfig {
  id: string;
  labelAr: string;
  labelEn: string;
  color: string;
  bgColor: string;
  textColor: string;
  dotColor: string;
  order: number;
}

export const LEAD_STAGES: Record<string, StageConfig> = {
  new: {
    id: "new",
    labelAr: "جديد",
    labelEn: "New",
    color: "#6366F1",
    bgColor: "bg-brand-100 dark:bg-brand-900/30",
    textColor: "text-brand-700 dark:text-brand-300",
    dotColor: "bg-brand-500",
    order: 1,
  },
  contacted: {
    id: "contacted",
    labelAr: "تم التواصل",
    labelEn: "Contacted",
    color: "#818CF8",
    bgColor: "bg-blue-100 dark:bg-blue-900/30",
    textColor: "text-blue-700 dark:text-blue-300",
    dotColor: "bg-blue-500",
    order: 2,
  },
  qualified: {
    id: "qualified",
    labelAr: "مؤهل",
    labelEn: "Qualified",
    color: "#8B5CF6",
    bgColor: "bg-violet-100 dark:bg-violet-900/30",
    textColor: "text-violet-700 dark:text-violet-300",
    dotColor: "bg-violet-500",
    order: 3,
  },
  pitched: {
    id: "pitched",
    labelAr: "تم العرض",
    labelEn: "Pitched",
    color: "#A78BFA",
    bgColor: "bg-purple-100 dark:bg-purple-900/30",
    textColor: "text-purple-700 dark:text-purple-300",
    dotColor: "bg-purple-500",
    order: 4,
  },
  objection: {
    id: "objection",
    labelAr: "اعتراض",
    labelEn: "Objection",
    color: "#F59E0B",
    bgColor: "bg-warning-100 dark:bg-warning-500/10",
    textColor: "text-warning-700 dark:text-warning-300",
    dotColor: "bg-warning-500",
    order: 5,
  },
  trial_booked: {
    id: "trial_booked",
    labelAr: "تجربة محجوزة",
    labelEn: "Trial Booked",
    color: "#06B6D4",
    bgColor: "bg-cyan-100 dark:bg-cyan-900/30",
    textColor: "text-cyan-700 dark:text-cyan-300",
    dotColor: "bg-cyan-500",
    order: 6,
  },
  trial_done: {
    id: "trial_done",
    labelAr: "تم التجربة",
    labelEn: "Trial Done",
    color: "#14B8A6",
    bgColor: "bg-teal-100 dark:bg-teal-900/30",
    textColor: "text-teal-700 dark:text-teal-300",
    dotColor: "bg-teal-500",
    order: 7,
  },
  closing: {
    id: "closing",
    labelAr: "جاري الإقفال",
    labelEn: "Closing",
    color: "#10B981",
    bgColor: "bg-success-100 dark:bg-success-500/10",
    textColor: "text-success-700 dark:text-success-500",
    dotColor: "bg-success-500",
    order: 8,
  },
  paid: {
    id: "paid",
    labelAr: "تم الدفع",
    labelEn: "Paid",
    color: "#059669",
    bgColor: "bg-emerald-100 dark:bg-emerald-900/30",
    textColor: "text-emerald-700 dark:text-emerald-300",
    dotColor: "bg-emerald-600",
    order: 9,
  },
  lost: {
    id: "lost",
    labelAr: "خسرناه",
    labelEn: "Lost",
    color: "#EF4444",
    bgColor: "bg-danger-100 dark:bg-danger-500/10",
    textColor: "text-danger-700 dark:text-danger-500",
    dotColor: "bg-danger-500",
    order: 10,
  },
  unresponsive: {
    id: "unresponsive",
    labelAr: "لا يرد",
    labelEn: "Unresponsive",
    color: "#9CA3AF",
    bgColor: "bg-gray-100 dark:bg-gray-800/50",
    textColor: "text-gray-600 dark:text-gray-400",
    dotColor: "bg-gray-400",
    order: 11,
  },
};

/** Stages ordered for Kanban view (active stages only) */
export const KANBAN_STAGES = [
  "new",
  "contacted",
  "qualified",
  "pitched",
  "objection",
  "trial_booked",
  "trial_done",
  "closing",
] as const;

/** Get stage config by id, with fallback */
export function getStageConfig(stageId: string): StageConfig {
  return (
    LEAD_STAGES[stageId] ?? {
      id: stageId,
      labelAr: stageId,
      labelEn: stageId,
      color: "#9CA3AF",
      bgColor: "bg-gray-100",
      textColor: "text-gray-600",
      dotColor: "bg-gray-400",
      order: 99,
    }
  );
}